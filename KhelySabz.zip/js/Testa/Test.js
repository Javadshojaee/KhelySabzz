async function Test() {
  let tests = "";
  let data = await fetch("http://localhost:3000/Advertisement");
  let res = await data.json();

  tests = res?.map((tes) => {
    return `<div class="Card">
          <img src=${tes.TestSrc} alt="Test">
        </div>`;
  });
  document
    .querySelector("#Advertisement")
    .insertAdjacentHTML("beforeend", tests.join(" "));
}

export default Test;
