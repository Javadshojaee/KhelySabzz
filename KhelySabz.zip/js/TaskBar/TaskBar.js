async function TaskBar() {
  let Tasks = "";
  let data = await fetch("http://localhost:3000/TaskBar");
  let res = await data.json();
  Tasks = res?.map((Tak) => {
    return `<div class="Task">${Tak.TaskText}</div>`;
  });
  document.querySelector("#TaskBar").insertAdjacentHTML("beforeend",Tasks.join(" "))
}

export default TaskBar