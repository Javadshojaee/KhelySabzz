async function Banneres() {
  let Banners = "";
  let data = await fetch("http://localhost:3000/Banner");
  let res = await data.json();
  Banners = res?.map((Ban) => {
    return `  <a href="#">
          <img src=${Ban.BannerSrc} alt="Banners">
        </a>`;
  });
  document.querySelector("#Banner").insertAdjacentHTML("beforeend",Banners.join(" "))
}
export default Banneres
