async function NoteBooks() {
  let Notes = "";
  let data = await fetch("http://localhost:3000/NoteBook");
  let res = await data.json();
  Notes = res?.map((not) => {
    return ` <div class="swiper-slide">
            <img src=${not.NoteSrc} alt="ImagesBooks" />
            <p>${not.Ntext}</p>
            <span>${not.NotePrice}</span>
          </div>`;
  });
  document.querySelector("#NotesBoooks").insertAdjacentHTML("beforeend",Notes)
}
export default NoteBooks
