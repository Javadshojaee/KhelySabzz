async function Suggestions() {
  let Sugges = "";
  let data = await fetch("http://localhost:3000/Suggestions");
  let res = await data.json();
  Sugges = res?.map((Sug) => {
    return `<div class="swiper-slide">
            <img src=${Sug.SuggestionsSrc} alt="ImagesBooks" />
            <p>${Sug.Descriptiun}</p>
            <h6>${Sug.OldPrice}</h6>
            <span>${Sug.Price}</span>
          </div>`;
  });
  document.querySelector("#SuggestionsSwiper").insertAdjacentHTML("beforeend",Sugges.join(" "))
}
export default Suggestions