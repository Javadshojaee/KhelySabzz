async function Right() {
  let Rig = "";
  let data = await fetch("http://localhost:3000/RightFooter");
  let res = await data.json();
  Rig = res?.map((re) => {
    return `<img src=${re.RightSrc} alt="Images" />
          <h3>${re.H3Text}</h3>
          <p>${re.PFooter}</p>`;
  });
  document
    .querySelector("#RightFooter")
    .insertAdjacentHTML("beforeend", Rig.join(" "));
}

async function Left() {
  let lef = "";
  let data = await fetch("http://localhost:3000/LeftFooter");
  let res = await data.json();
  lef = res?.map((Le) => {
    return `<a href="#">
              <img src=${Le.FootImg} alt="FooterImage" />
            </a>`;
  });
  document.querySelector("#botton").insertAdjacentHTML("beforeend",lef.join(" "))
}
export { Right , Left};
