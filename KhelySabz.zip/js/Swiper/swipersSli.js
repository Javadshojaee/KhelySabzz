async function SwipersLi() {
  let swipers = "";
  let data = await fetch("http://localhost:3000/ImageSlider");
  let res = await data.json();
  
  swipers = res?.map((swip) => {
    return `<div class="swiper-slide">
              <a href=${swip.HrefSlide}>
                <img src=${swip.SrcSlider} alt="ImgeSwiper" />
              </a>
            </div>`;
  });
  document.querySelector("#swiper-Wrpper").insertAdjacentHTML("beforeend",swipers.join(" "))
}

export default SwipersLi
